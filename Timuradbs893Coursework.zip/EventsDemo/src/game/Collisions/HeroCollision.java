package game.Collisions;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import game.Bodies.Boss;
import game.Bodies.Hero;
import game.Bodies.Villain;

// If hero collides with Boss then decrement live count
public class HeroCollision implements CollisionListener {
    private Hero hero;

    public HeroCollision(Hero hero){
        this.hero = hero;
    }
    //boss collisions
    @Override
    public void collide(CollisionEvent a) {

        if(a.getReportingBody() instanceof Boss && a.getOtherBody() == hero){
            //reduces live count by 1 (boss)
            Hero.setLiveCount(Hero.getLiveCount()-1);
            //prints amount of lives left (boss)
            System.out.println("You have "+Hero.getLiveCount()+" Lives Left!!!");
        }else if(a.getReportingBody()instanceof Villain && a.getOtherBody() == hero){
            //reduces live count by 1 (villain)
            Hero.setLiveCount(Hero.getLiveCount()-1);
            //prints amount of lives left (villain)
            System.out.println(Hero.getLiveCount());
        }
    }

}