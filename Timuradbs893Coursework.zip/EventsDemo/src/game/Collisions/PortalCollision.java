package game.Collisions;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import city.cs.engine.SoundClip;
import game.Main.Game;
import game.Main.GameLevel;
import game.Bodies.Portal;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;

public class PortalCollision implements CollisionListener {

    private GameLevel level;
    private Game game;

    public PortalCollision(GameLevel level, Game game){
        this.level = level;
        this.game = game;

    }
    // sound effect for entering portal(Totoro)
    private static SoundClip PortalSound;
    static {
        try {
            PortalSound = new SoundClip("data/portalping.wav");
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
        }
    }

    @Override
    public void collide(CollisionEvent e) {
        //if Hero collided with Portal and the
        //conditions for completing the level are fulfilled
        //goToNextLevel
        if (e.getOtherBody() instanceof Portal
                && level.isComplete()){
            PortalSound.play();
            game.goToNextLevel();
        }
    }
}
