package game.Collisions;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import city.cs.engine.SoundClip;
import game.Bodies.Coins;
import game.Bodies.Hero;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;


// If coins collide with player they get destroyed

public class CoinsPickup implements CollisionListener {

    private Hero hero;
    public CoinsPickup(Hero s){
        this.hero = s;
    }
    //sound effect when coin collides with hero body
    private static SoundClip CoinSound;
    static {
        try {
            CoinSound = new SoundClip("data/coinping2.wav");
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
        }
    }

    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() instanceof Coins) {
            //plays coins sound
            CoinSound.play();
            //add coins to coin count
            hero.addCoins();
            //adds score to score count
            Hero.setScoreCount(Hero.getScoreCount()+100);
            //destroys coin
            e.getOtherBody().destroy();
            // prints total score across levels
            System.out.println("Score: " + Hero.getScoreCount() + " Points");
        }
    }
}