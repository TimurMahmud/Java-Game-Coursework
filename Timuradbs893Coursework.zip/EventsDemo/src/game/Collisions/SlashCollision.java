package game.Collisions;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import city.cs.engine.SoundClip;
import city.cs.engine.StaticBody;
import game.Bodies.Boss;
import game.Bodies.Hero;
import game.Bodies.Slash;
import game.Bodies.Villain;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;

// If projectile collides with Boss or any dynamic body it will get destroyed
public class SlashCollision implements CollisionListener {
    private Slash slash;
    public SlashCollision(Slash s){this.slash = s;}

    private static SoundClip KillSound;
    static {
        try {
            KillSound = new SoundClip("data/kill.wav");
        } catch(UnsupportedAudioFileException | IOException | LineUnavailableException e){

        }
    }


    @Override
    public void collide(CollisionEvent e){
        //destroy projectile if it collides with a static body eg walls and platforms
        if(e.getOtherBody() instanceof StaticBody){
            slash.destroy();}
        //decrement boss and villain life count and increment score
        else if(e.getOtherBody() instanceof Boss){
            KillSound.play();
            Hero.setScoreCount(Hero.getScoreCount()+500);
            System.out.println("Score: " + Hero.getScoreCount() + " Points");
            ((Boss) e.getOtherBody()).decreaseHealth();
            slash.destroy(); }
        else if(e.getOtherBody()instanceof Villain){
            KillSound.play();
            Hero.setScoreCount(Hero.getScoreCount()+500);
            System.out.println("Score: " + Hero.getScoreCount() + " Points");
            ((Villain) e.getOtherBody()).decreaseVillainHealth();
            slash.destroy();
        }
    }


}



