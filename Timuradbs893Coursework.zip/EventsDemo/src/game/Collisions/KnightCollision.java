package game.Collisions;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import city.cs.engine.SoundClip;
import game.Bodies.Hero;
import game.Bodies.Knight;
import game.Bodies.Slash;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;

// Knight colliding with a  projectile causes it to destroy

public class KnightCollision implements CollisionListener {
    private Hero hero;
    private Knight knight;

    public KnightCollision(Knight k) {
        this.knight = k;
    }
    // sound effect for when slash collides with villain or boss
    private static SoundClip KillSound;
    static {
        try {
            KillSound = new SoundClip("data/kill.wav");
        } catch(UnsupportedAudioFileException | IOException | LineUnavailableException e){

        }
    }

    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() instanceof Slash) {
            //plays the sound effect
            KillSound.play();
            //add x amount of score to total score
            Hero.setScoreCount(Hero.getScoreCount()+1000);
            //print total score
            System.out.println("Score: " + Hero.getScoreCount() + " Points");
            //destroy knight
            knight.destroy();

        }
    }
}