package game.Level1;

import city.cs.engine.*;
import game.Bodies.Coins;
import game.Collisions.CoinsPickup;
import game.Collisions.HeroCollision;
import game.Main.Game;
import game.Main.GameLevel;
import org.jbox2d.common.Vec2;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;
import java.util.Timer;

public class Level1 extends GameLevel {

    public Level1(Game game) {
        //the base class will create the Hero, Boss and Portal
        super(game);


        // Small Platforms

        // add platform to game wall using small platform class
        PlatformSmall platformSmall = new PlatformSmall(this);
        // set platform position
        platformSmall.setPosition(new Vec2(-7, -13));

        PlatformSmall platformSmall1 = new PlatformSmall(this);
        platformSmall1.setPosition(new Vec2(-2, 3));

        PlatformSmall platformSmall2 = new PlatformSmall(this);
        platformSmall2.setPosition(new Vec2(4, -17));

        PlatformSmall platformSmall3 = new PlatformSmall(this);
        platformSmall3.setPosition(new Vec2(-12, -5));

        // Large Platform(s)
        PlatformLarge platformLarge1 = new PlatformLarge(this);
        platformLarge1.setPosition(new Vec2(15, 11.5f));

        // Ground Platform
        PlatformGround platformGround = new PlatformGround(this);
        platformGround.setPosition(new Vec2(0, -24.5f));

        //ceiling

        Shape ceilingShape = new BoxShape(32f, 0.5f);
        StaticBody ceiling = new StaticBody(this, ceilingShape);
        ceiling.setPosition(new Vec2(0, 26));

        // Invisible Walls
        Shape wallShape = new BoxShape(0.5f, 32f);
        StaticBody wall1 = new StaticBody(this, wallShape);
        wall1.setPosition(new Vec2(-26, 0));

        StaticBody wall2 = new StaticBody(this, wallShape);
        wall2.setPosition(new Vec2(26, 0));
    }

        //populate world for loading and saving
        @Override
        public void populate(Game game){
        super.populate(game);

            try {
                gameMusic = new SoundClip("data/P5BGM.wav");
                gameMusic.loop();
                gameMusic.setVolume(0.05);
                System.out.println("Playing P5BGM");
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            }

            //get Hero
            getHero().setPosition(new Vec2(8, -10));
            CoinsPickup pickup = new CoinsPickup(getHero());
            getHero().addCollisionListener(pickup);

            //get Boss
            getBoss().setPosition(new Vec2(-8,-10));
            getBoss().addCollisionListener(new HeroCollision(getHero()));
            Timer t = new java.util.Timer();
            t.scheduleAtFixedRate(
                    new java.util.TimerTask(){
                        @Override
                        public void run() {
                            getBoss().stopWalking();
                            getBoss().startWalking(-10f);
                        }
                    },3000,6000
            );

            Timer t2 = new java.util.Timer();
            t2.scheduleAtFixedRate(
                    new java.util.TimerTask(){
                        @Override
                        public void run() {
                            getBoss().stopWalking();
                            getBoss().startWalking(10f);
                        }
                    },6000,3000
            );

            //get Portal
            getPortal().setPosition(new Vec2(20,15.5f));

            // Coins
            // for loop to add coins in intervals
            for(int i = 0; i < 3; ++i){
                Coins coins = new Coins(this);
                coins.setPosition(new Vec2(-4+i*2,6f));}

            for(int i = 0; i < 3; ++i){
                Coins coins2 = new Coins(this);
                coins2.setPosition(new Vec2(-14f+i*2,0f));}

            for(int i = 0; i < 3; ++i){
                Coins coins3 = new Coins(this);
                coins3.setPosition(new Vec2(7.5f+i*2,14f));}
        }



    //if level conditions are met proceed to next level
    @Override
    public boolean isComplete() {
        if (getHero().getScoreCount() >=2000)
            return true;
        else
            return false;
    }

    @Override
    public String getLevelName() {
        return "Level1";
    }

}
