package game.Level1;

import city.cs.engine.*;

import city.cs.engine.*;
// Large grass platform
public class PlatformLarge extends StaticBody {

    private static final Shape platformLargeShape = new BoxShape(10,1.2f);


    private static final BodyImage image =
            new BodyImage("data/platform2.png", 5f);


    public PlatformLarge(World world) {
        super(world, platformLargeShape);
        addImage(image);
    }
}