package game.Level1;

import city.cs.engine.*;

import city.cs.engine.*;
// Ground grass platform
public class PlatformGround extends StaticBody {

    private static final Shape platformGroundShape = new BoxShape(30,1.2f);


    private static final BodyImage image =
            new BodyImage("data/LongTile.png", 5f);


    public PlatformGround(World world) {
        super(world, platformGroundShape);
        addImage(image);
    }
}