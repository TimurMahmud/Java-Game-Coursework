package game.Level3;

        import city.cs.engine.BoxShape;
        import city.cs.engine.Shape;
        import city.cs.engine.StaticBody;
        import game.Bodies.Coins;
        import game.Bodies.Knight;
        import game.Bodies.Villain;
        import game.Collisions.CoinsPickup;
        import game.Collisions.HeroCollision;
        import game.Collisions.KnightCollision;
        import game.Level1.PlatformGround;
        import game.Main.Game;
        import game.Main.GameLevel;
        import org.jbox2d.common.Vec2;

        import java.util.Timer;

public class Level3 extends GameLevel {

    private Villain villain;

    public Level3(Game game) {
        //the base class will create the Hero, Boss and Portal
        super(game);

        // Ground Platform
        PlatformGround platformGround = new PlatformGround(this);
        platformGround.setPosition(new Vec2(0, -24.5f));

        // Small Platforms
        PlatformSmall3 platformSmall1 = new PlatformSmall3(this);
        platformSmall1.setPosition(new Vec2(-12, 12));

        PlatformSmall3 platformSmall2 = new PlatformSmall3(this);
        platformSmall2.setPosition(new Vec2(12, 12));

        PlatformSmall3 platformSmall3 = new PlatformSmall3(this);
        platformSmall3.setPosition(new Vec2(0, -15));

        PlatformSmall3 platformSmall4 = new PlatformSmall3(this);
        platformSmall4.setPosition(new Vec2(0, 0));

        //ceiling
        Shape ceilingShape = new BoxShape(32f, 0.5f);
        StaticBody ceiling = new StaticBody(this, ceilingShape);
        ceiling.setPosition(new Vec2(0, 26));

        // Invisible Walls
        Shape wallShape = new BoxShape(0.5f, 32f);
        StaticBody wall1 = new StaticBody(this, wallShape);
        wall1.setPosition(new Vec2(-26, 0));

        StaticBody wall2 = new StaticBody(this, wallShape);
        wall2.setPosition(new Vec2(26, 0));
    }
    //populate world for loading and saving
        @Override
        public void populate (Game game){
            super.populate(game);

            //Portal
            getPortal().setPosition(new Vec2(0, -11));

            //boss
            getBoss().setPosition(new Vec2(12, 13));
            getBoss().addCollisionListener(new HeroCollision(getHero()));
            // Timer to move Boss in intervals
            Timer t = new java.util.Timer();
            t.scheduleAtFixedRate(
                    new java.util.TimerTask() {

                        public void run() {
                            getBoss().stopWalking();
                            getBoss().startWalking(10f);
                        }
                    }, 1500, 2000
            );

            Timer t2 = new java.util.Timer();
            t2.scheduleAtFixedRate(
                    new java.util.TimerTask() {

                        public void run() {
                            getBoss().stopWalking();
                            getBoss().startWalking(-10f);
                        }
                    }, 1500, 2000
            );

            //Hero
            getHero().setPosition(new Vec2(0, 1));
            CoinsPickup pickup = new CoinsPickup(getHero());
            getHero().addCollisionListener(pickup);

            //Villain
            villain = new Villain(this);
            villain.setPosition(new Vec2(-12, 13));
            villain.addCollisionListener(new HeroCollision(getHero()));
            // Timer to move Villain in intervals
            Timer s = new java.util.Timer();
            s.scheduleAtFixedRate(
                    new java.util.TimerTask() {

                        public void run() {
                            villain.stopWalking();
                            villain.startWalking(-10f);
                        }
                    }, 3000, 6000
            );

            Timer s2 = new java.util.Timer();
            s2.scheduleAtFixedRate(
                    new java.util.TimerTask() {

                        public void run() {
                            villain.stopWalking();
                            villain.startWalking(10f);
                        }
                    }, 6000, 3000
            );
        }


    //if level conditions are met proceed to next level
    @Override
    public boolean isComplete() {
        if (getHero().getScoreCount() >= 10)
            return true;
        else
            return false;
    }

    @Override
    public String getLevelName() {
        return "Level3";
    }
}