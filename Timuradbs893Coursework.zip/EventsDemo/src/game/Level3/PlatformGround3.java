package game.Level3;

import city.cs.engine.*;

import city.cs.engine.*;
// Ground grass platform
public class PlatformGround3 extends StaticBody {

    private static final Shape platformGroundShape = new BoxShape(30,2f);


    private static final BodyImage image =
            new BodyImage("data/longtile.png", 5f);


    public PlatformGround3(World world) {
        super(world, platformGroundShape);
        addImage(image);
    }
}