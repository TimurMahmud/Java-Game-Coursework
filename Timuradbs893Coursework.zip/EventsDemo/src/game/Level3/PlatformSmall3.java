package game.Level3;

import city.cs.engine.*;
//Small grass platform
public class PlatformSmall3 extends StaticBody {

    private static final Shape platform1Shape = new BoxShape(3,1.2f);


    private static final BodyImage image =
            new BodyImage("data/platform1.png", 5f);


    public PlatformSmall3(World world) {
        super(world, platform1Shape);
        addImage(image);
    }
}
