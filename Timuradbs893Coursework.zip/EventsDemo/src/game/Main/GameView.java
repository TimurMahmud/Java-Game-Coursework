package game.Main;

import city.cs.engine.UserView;
import city.cs.engine.World;
import game.Bodies.Hero;
import game.Level1.Level1;
import game.Level2.Level2;
import game.Level3.Level3;

import javax.swing.*;
import java.awt.*;
// Change Background and zoom scale
public class GameView extends UserView {
    private Image levelbg;
    private GameLevel level = Game.getLevel();
    //background changer when proceeding through levels
    public GameView(World w, int width, int height) {
        super(w, width, height);

        if(Game.level instanceof Level1){
            levelbg = new ImageIcon("data/gamebg.png").getImage();
        }else if(Game.level instanceof Level2){
            levelbg = new ImageIcon("data/gamebg2.png").getImage();
        }else if(Game.level instanceof Level3){
            levelbg = new ImageIcon("data/gamebg3.png").getImage();
        }
    }

    @Override
    protected void paintBackground(Graphics2D g) {
        g.drawImage(levelbg, 0, 0, this);
    }

    //UI DISPLAYING HERO SCORE AND HERO HEALTH POINTS
    @Override
    protected void paintForeground(Graphics2D g) {
        g.setColor(Color.white);
        g.drawString("Score: " + Hero.getScoreCount(), 10, 20);
        g.drawString("HP: " + Hero.getLiveCount(), 100, 20 );
    }




}
