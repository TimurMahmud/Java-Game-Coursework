package game.Main;

import city.cs.engine.SoundClip;
import city.cs.engine.World;
import game.Bodies.Boss;
import game.Bodies.Hero;
import game.Bodies.Portal;
import game.Collisions.PortalCollision;
import game.Main.GameSaveLoad;

public abstract class GameLevel extends World {
    public static SoundClip gameMusic;
    private Hero hero;
    private Boss boss;
    private Portal portal;

    public GameLevel(Game game){
    }

    public void populate(Game game){

        //Hero
        hero = new Hero(this);
        //Boss
        boss = new Boss(this);
        //Portal
        portal = new Portal(this);
        PortalCollision encounter = new PortalCollision(this, game);
        hero.addCollisionListener(encounter);
    }

    public static SoundClip getGameMusic() {
        return gameMusic;
    }

    public void setHero(Hero h){

        hero  = h;
    }

    public Hero getHero (){
        return hero;
    }


    public Portal getPortal() {
        return portal;
    }

    public Boss getBoss(){

        return boss;
    }
    public void setBoss(Boss b){
        boss = b;
    }


    public abstract boolean isComplete();

    public abstract String getLevelName();
}
