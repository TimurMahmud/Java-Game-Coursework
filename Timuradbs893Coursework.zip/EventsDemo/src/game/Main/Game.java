package game.Main;

import game.Controllers.HeroController;
import game.Controllers.MouseHandler;
import game.GUI.Button;
import game.GUI.VolumeSlider;
import game.Level1.Level1;
import game.Level2.Level2;
import game.Level3.Level3;

import javax.swing.*;
import java.awt.*;


/**
 * A world with some bodies.
 */
public class Game {

    /** The World in which the bodies move and interact. */
    public static GameLevel level;

    /** A graphical display of the world (a specialised JPanel). */
    private GameView view;
    private HeroController controller;
    private JFrame frame;

    /** Initialise a new Game. */
    public Game() {

        // make the world
        //GameWorld world = new GameWorld();

        // initialize level to Level1
        level = new Level1(this);
        level.populate(this);

        // Change Gravity
        level.setGravity(13f);

        // make a view
        view = new GameView(level, 1000, 1000);
        view.setZoom(20);

        // uncomment this to draw a 1-metre grid over the view
        // view.setGridResolution(1);

        // add some mouse actions
        // add this to the view, so coordinates are relative to the view
        view.addMouseListener(new MouseHandler(level, view));
        controller = new HeroController(level.getHero());
        view.addKeyListener(controller);
        view.addMouseListener(new GiveFocus(view));
        // add the view to a frame (Java top level window)
        frame = new JFrame("Basic world");
        frame.add(view);
        frame.add(VolumeSlider.createSlider(), BorderLayout.WEST);
        frame.add(Button.createButton(this),BorderLayout.NORTH);
        // enable the frame to quit the application
        // when the x button is pressed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        // don't let the frame be resized
        frame.setResizable(false);
        // size the frame to fit the world view
        frame.pack();
        // finally, make the frame visible
        frame.setVisible(true);

        // uncomment this to make a debugging view
        //JFrame debugView = new DebugViewer(world, 500, 500);

        // start the game
        level.start();
    }

    public void setLevel(GameLevel level){
        this.level.stop();
        this.level = level;
        view.setWorld(this.level);
        this.level.start();
    }

    public void goToNextLevel(){
        //Level switcher
        if (level instanceof Level1){
            level.stop();
            frame.remove(view);
            //GameLevel.gameMusic.stop();
            level = new Level2(this);
            level.populate(this);
            view.setWorld(level);
            view = new GameView(level, 1000, 1000);
            controller.updateHero(level.getHero());
            view.addMouseListener(new GiveFocus(view));
            frame.add(view);
            view.setWorld(level);
            frame.pack();
            controller.updateHero(level.getHero());
            controller = new HeroController(level.getHero());
            view.addKeyListener(controller);
            level.start();

        }
        else if (level instanceof Level2){
            level.stop();
            frame.remove(view);
            //GameLevel.gameMusic.stop();
            level = new Level3(this);
            level.populate(this);
            view.setWorld(level);
            view = new GameView(level, 1000, 1000);
            controller.updateHero(level.getHero());
            view.addMouseListener(new GiveFocus(view));
            frame.add(view);
            view.setWorld(level);
            frame.pack();
            controller.updateHero(level.getHero());
            controller = new HeroController(level.getHero());
            view.addKeyListener(controller);
            level.start();
        }
        else if (level instanceof Level3){
            System.out.println("Well done! Game complete.");
            System.exit(0);
        }
    }

    public static  GameLevel getLevel(){return level;}

    /** Run the game. */
    public static void main(String[] args) {

        // Controls
        System.out.println("**********************************************************************************************");
        System.out.println("* Controls:                                                                                  *");
        System.out.println("* Left Arrow Key - Walk Left                                                                 *");
        System.out.println("* Right Arrow Key - Walk Right                                                               *");
        System.out.println("* Up Arrow Key - Jump                                                                        *");
        System.out.println("* Num Key 1 - Slash Left                                                                     *");
        System.out.println("* Num Key 2 - Slash Up                                                                       *");
        System.out.println("* Num Key 3 - Slash Right                                                                    *");
        System.out.println("**********************************************************************************************");
        // Instructions
        System.out.println("* Collect all the coins, kill all the enemies and report back to Totoro(GREY BEAR) TO WIN!!!!*");
        System.out.println("**********************************************************************************************");

        new Game();
    }
}
