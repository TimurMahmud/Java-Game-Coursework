package game.Main;

import city.cs.engine.DynamicBody;
import city.cs.engine.StaticBody;
import game.Bodies.*;
import game.Level1.Level1;
import game.Level2.Level2;
import game.Level3.Level3;
import org.jbox2d.common.Vec2;
import game.Main.GameLevel;

import javax.swing.text.View;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;



public class GameSaveLoad {

    public static void save(GameLevel level,String fileName)
            throws IOException
    {
        boolean append = false;
        FileWriter writer = null;
        try {
            writer = new FileWriter(fileName, append);
            writer.write(level.getLevelName() + "\n");

            for(StaticBody body: level.getStaticBodies()){
                if(body instanceof Portal){
                    writer.write("Portal," + body.getPosition().x + "," +
                            body.getPosition().y + "," + "\n");

                }
                else if(body instanceof Knight){
                    writer.write("Knights," + body.getPosition().x + "," +
                            body.getPosition().y + "\n");

                }
            }
            for (DynamicBody body : level.getDynamicBodies()){
                if(body instanceof Hero){
                    writer.write("Hero," + body.getPosition().x + "," +
                            body.getPosition().y + "," +
                            ((Hero) body).getCoinCount() + "\n");

                }
                else if (body instanceof Boss){
                    writer.write("Boss," + body.getPosition().x + "," +
                            body.getPosition().y + "\n" );

                }
                else if (body instanceof Coins){
                    writer.write("Coins," + body.getPosition().x + "," +
                            body.getPosition().y + "\n" );

                }

                else if (body instanceof Villain){
                    writer.write("Villain," + body.getPosition().x + "," +
                            body.getPosition().y + "\n" );

                }
            }

        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }

    public static GameLevel load(Game game, String fileName)
    throws IOException{

        FileReader fr = null;
        BufferedReader reader = null;
        try {
            System.out.println("Reading " + fileName + " ...");
            fr = new FileReader(fileName);
            reader = new BufferedReader(fr);
            String line = reader.readLine();

                GameLevel level = null;
                if(line.equals("Level1"))
                    level = new Level1(game);
                else if (line.equals("Level2"))
                    level = new Level2(game);
                else if (line.equals("Level3"))
                    level = new Level3(game);

                line = reader.readLine();
                while (line != null){
                    String[] tokens = line.split(",");

                    if(tokens[0].equals("Hero")){
                        Hero h = new Hero(level);
                        float x = Float.parseFloat(tokens[1]);
                        float y = Float.parseFloat(tokens[2]);
                        h.setPosition(new Vec2(x,y));
                        //int scoreCount = Integer.parseInt(tokens[3]);

                        level.setHero(h);

                    }
                    else if(tokens[0].equals("Boss")){
                        Boss b = new Boss(level);
                        float x = Float.parseFloat(tokens[1]);
                        float y = Float.parseFloat(tokens[2]);
                        b.setPosition(new Vec2(x,y));

                        level.setBoss(b);
                    }
                    else if(tokens[0].equals("Coins")){
                        Coins c = new Coins(level);
                        float x = Float.parseFloat(tokens[1]);
                        float y = Float.parseFloat(tokens[2]);
                        c.setPosition(new Vec2(x,y));

                    }
                    else if(tokens[0].equals("Knights")){
                        Knight k = new Knight(level);
                        float x = Float.parseFloat(tokens[1]);
                        float y = Float.parseFloat(tokens[2]);
                        k.setPosition(new Vec2(x,y));
                    }

                    else if(tokens[0].equals("Villain")){
                        Villain v = new Villain(level);
                        float x = Float.parseFloat(tokens[1]);
                        float y = Float.parseFloat(tokens[2]);
                        v.setPosition(new Vec2(x,y));
                    }
                    else if(tokens[0].equals("Portal")){
                        Portal p = new Portal(level);
                        float x = Float.parseFloat(tokens[1]);
                        float y = Float.parseFloat(tokens[2]);
                        p.setPosition(new Vec2(x,y));
                    }


                    line = reader.readLine();
                }

                return level;

        } finally {
            if (reader != null) {
                reader.close();
            }
            if (fr != null) {
                fr.close();
            }
        }

    }
}

