package game.Bodies;

import city.cs.engine.*;

public class Knight extends StaticBody {
    //knight shape and hit box
    private static final Shape runesShape = new PolygonShape(
            -2.13f,-1.9f, 1.71f,-1.88f, 0.08f,2.35f, -2.13f,1.22f);
    //knight image
    private static final BodyImage image =
            new BodyImage("data/drunkknight.gif", 5f);


    public Knight(World world) {
        super(world, runesShape);
        addImage(image);
    }


}