package game.Bodies;

import city.cs.engine.*;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;

public class Villain extends Walker {


    //Villain shape and hit box
    private static final Shape villainShape = new PolygonShape(
            -2.17f,-2.34f, 2.13f,-2.34f, 2.04f,2.13f, -2.15f,2.22f, -2.24f,-2.09f);
    //villain image
    private static final BodyImage image =
            new BodyImage("data/boss.gif", 5f);

    private int villainHealth;
    //sound effect when villain is destroyed
    private static SoundClip FinalKillSound;
    static {
        try {
            FinalKillSound = new SoundClip("data/finalkill.wav");
        } catch(UnsupportedAudioFileException | IOException | LineUnavailableException e){
        }
    }

    public Villain(World world) {
        super(world, villainShape);
        addImage(image);
        //villain starting health
        villainHealth = 40;
    }
    //Villain health decrements
    public void decreaseVillainHealth(){
        //decrease health point by 1
        villainHealth--;
        //when villain loses all healthpoints it gets destroyed
        if (villainHealth < 1) {
            FinalKillSound.play();
            this.destroy();
        }
    }

}