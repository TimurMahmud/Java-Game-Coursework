package game.Bodies;

import city.cs.engine.*;

public class Boss extends Walker {
        // Boss shape and hit box
    private static final Shape bossShape = new PolygonShape(
            -2.17f,-2.34f, 2.13f,-2.34f, 2.04f,2.13f, -2.15f,2.22f, -2.24f,-2.09f);
        //Boss image
    private static final BodyImage image =
            new BodyImage("data/boss3.gif", 5f);

    private int health;

    public Boss(World world) {
        super(world, bossShape);
        addImage(image);
        health = 8;
    }
    //Health decrements for the boss when hit
    public void decreaseHealth(){
        health--;
        if (health < 1)
            this.destroy();
    }

}
