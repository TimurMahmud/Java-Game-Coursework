package game.Bodies;

import city.cs.engine.*;

public class Portal extends StaticBody {
    //portal shape and hit box
    private static final Shape portalShape = new PolygonShape(
            -1.24f,-1.92f, 1.26f,-1.89f, 0.86f,1.9f, -1.45f,1.91f, -1.7f,-1.82f);
    //portal image
    private static final BodyImage image =
            new BodyImage("data/portal2.gif", 7.5f);


    public Portal(World world) {
        super(world, portalShape);
        addImage(image);
    }
}
