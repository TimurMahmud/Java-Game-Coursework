package game.Bodies;

import city.cs.engine.*;

public class Coins extends DynamicBody {
        //Coin shape and hit box
    private static final Shape coinsShape = new CircleShape(1f);
        //coin image
    private static final BodyImage image =
            new BodyImage("data/coins.gif", 3f);

    public Coins(World world) {
        super(world,coinsShape);
        addImage(image);

    }
}
