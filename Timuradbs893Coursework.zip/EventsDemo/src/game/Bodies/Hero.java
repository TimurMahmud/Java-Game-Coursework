package game.Bodies;

import city.cs.engine.*;
import game.Main.Game;

public class Hero extends Walker {
    //hero shape and hit box
    private static final Shape heroShape = new PolygonShape(
            -1.0f,-2.07f, 0.77f,-2.17f, 0.84f,1.74f, -0.04f,2.06f, -0.88f,1.25f, -1.01f,-1.89f);
    //hero image
    private static final BodyImage image =
            new BodyImage("data/left.gif", 5f);

    private int coinCount;
    private static int liveCount;
    private static int scoreCount;

    public Hero(World world) {
        super(world, heroShape);
        addImage(image);
        //Starting coin count
        coinCount = 0;
        //Starting lives
        liveCount = 3;
    }

    // Coin Counter
    public void addCoins(){
        coinCount++;
        System.out.println("Cash Money!! Bring me my money!: " +
                "coinCount = " + coinCount);
    }

    public int getCoinCount(){
        return coinCount;
    }

    public void setCoinCount(int cc){
        coinCount = cc;
    }

   // Lives Counter

   public static int getLiveCount() {
       return liveCount;
   }

   public static void setLiveCount(int liveCount) {
       Hero.liveCount = liveCount;
       if(liveCount < 1){
           System.out.println("Game Over!! YOU LOSER!!");
           System.exit(0);

       }
   }

    //score counter

    public static int getScoreCount() {
        return scoreCount;
    }

    public static void setScoreCount(int scoreCount) {
        Hero.scoreCount = scoreCount;
    }





}