package game.Bodies;

import city.cs.engine.*;
// Tornado Slash
public class Slash extends Walker {
    //slash shape and hit box
    private static final Shape slashShape = new PolygonShape(
            -1.51f,1.64f, -0.33f,-2.05f, 1.73f,1.48f, -1.43f,1.73f);
    //slash image
    private static final BodyImage image =
            new BodyImage("data/slash.gif", 4f);


    public Slash(World world) {
        super(world, slashShape);
        addImage(image);
    }
}
