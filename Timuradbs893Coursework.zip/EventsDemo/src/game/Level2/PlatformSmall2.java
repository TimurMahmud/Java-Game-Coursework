package game.Level2;

import city.cs.engine.*;

import city.cs.engine.*;
// Large grass platform
public class PlatformSmall2 extends StaticBody {

    private static final Shape platformSmallShape = new BoxShape(2.5f,1.1f);


    private static final BodyImage image =
            new BodyImage("data/platformcastlesmall.png", 5f);


    public PlatformSmall2(World world) {
        super(world, platformSmallShape);
        addImage(image);
    }
}