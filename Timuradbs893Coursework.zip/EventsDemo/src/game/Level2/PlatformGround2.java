package game.Level2;

import city.cs.engine.*;

import city.cs.engine.*;
// Ground grass platform
public class PlatformGround2 extends StaticBody {

    private static final Shape platformGroundShape = new BoxShape(30,2f);


    private static final BodyImage image =
            new BodyImage("data/platformcastle.png", 5f);


    public PlatformGround2(World world) {
        super(world, platformGroundShape);
        addImage(image);
    }
}