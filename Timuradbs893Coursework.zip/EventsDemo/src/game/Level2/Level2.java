package game.Level2;

import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import game.Bodies.Coins;
import game.Bodies.Knight;
import game.Collisions.CoinsPickup;
import game.Collisions.HeroCollision;
import game.Collisions.KnightCollision;
import game.Main.Game;
import game.Main.GameLevel;
import org.jbox2d.common.Vec2;

import java.util.Timer;

public class Level2 extends GameLevel {

    public Level2(Game game) {
        //the base class will create the Hero, Boss and Portal
        super(game);

        // Ground Platform
        PlatformGround2 platformGround2 = new PlatformGround2(this);
        platformGround2.setPosition(new Vec2(0, -24.5f));

        //ceiling

        Shape ceilingShape = new BoxShape(32f, 0.5f);
        StaticBody ceiling = new StaticBody(this, ceilingShape);
        ceiling.setPosition(new Vec2(0, 26));

        // Small Platform(s)
        PlatformSmall2 platformSmall1 = new PlatformSmall2(this);
        platformSmall1.setPosition(new Vec2(15, -15f));

        PlatformSmall2 platformSmall2 = new PlatformSmall2(this);
        platformSmall2.setPosition(new Vec2(22.5f, -7.5f));

        PlatformSmall2 platformSmall3 = new PlatformSmall2(this);
        platformSmall3.setPosition(new Vec2(15, 0f));

        PlatformSmall2 platformSmall4 = new PlatformSmall2(this);
        platformSmall4.setPosition(new Vec2(22.5f, 7.5f));

        PlatformSmall2 platformSmall5 = new PlatformSmall2(this);
        platformSmall5.setPosition(new Vec2(15, 15f));

        PlatformGround2 platformGround6 = new PlatformGround2(this);
        platformGround6.setPosition(new Vec2(0, -24.5f));


        PlatformSmall2 platformSmall7 = new PlatformSmall2(this);
        platformSmall7.setPosition(new Vec2(-22f, -15f));

        PlatformSmall2 platformSmall8 = new PlatformSmall2(this);
        platformSmall8.setPosition(new Vec2(-22f, -7.5f));

        PlatformSmall2 platformSmall9 = new PlatformSmall2(this);
        platformSmall9.setPosition(new Vec2(-22f, 0f));

        PlatformSmall2 platformSmall10 = new PlatformSmall2(this);
        platformSmall10.setPosition(new Vec2(-22f, 7.5f));

        PlatformSmall2 platformSmall11 = new PlatformSmall2(this);
        platformSmall11.setPosition(new Vec2(-22f, 15f));

        // Invisible Walls
        Shape wallShape = new BoxShape(0.5f, 32f);
        StaticBody wall1 = new StaticBody(this, wallShape);
        wall1.setPosition(new Vec2(-26, 0));

        StaticBody wall2 = new StaticBody(this, wallShape);
        wall2.setPosition(new Vec2(26, 0));
    }
    //populate world for loading and saving
        @Override
        public void populate(Game game){
        super.populate(game);

            getPortal().setPosition(new Vec2(-22, -19f));
            //we're setting up coinsPickup here though we could
            //also add it to the GameLevel class
            getHero().addCollisionListener(new CoinsPickup(getHero()));

            //Hero
            getHero().setPosition(new Vec2(8, -10));
            CoinsPickup pickup = new CoinsPickup(getHero());
            getHero().addCollisionListener(pickup);

            //Boss
            getBoss().setPosition(new Vec2(-8,-10));
            getBoss().addCollisionListener(new HeroCollision(getHero()));

            //Timer to move boss in intervals
            Timer t = new java.util.Timer();
            t.scheduleAtFixedRate(
                    new java.util.TimerTask(){
                        @Override
                        public void run() {
                            getBoss().stopWalking();
                            getBoss().startWalking(-10f);
                        }
                    },3000,6000
            );

            Timer t2 = new java.util.Timer();
            t2.scheduleAtFixedRate(
                    new java.util.TimerTask(){
                        @Override
                        public void run() {
                            getBoss().stopWalking();
                            getBoss().startWalking(10f);
                        }
                    },6000,3000
            );

            //Knights to destroy
            Knight knight1 = new Knight(this);
            knight1.setPosition(new Vec2(-23,-11.8f));
            knight1.addCollisionListener(new KnightCollision(knight1));

            Knight knight2 = new Knight(this);
            knight2.setPosition(new Vec2(-23,-4.3f));
            knight2.addCollisionListener(new KnightCollision(knight2));


            Knight knight3 = new Knight(this);
            knight3.setPosition(new Vec2(-23,3.2f));
            knight3.addCollisionListener(new KnightCollision(knight3));

            Knight knight4 = new Knight(this);
            knight4.setPosition(new Vec2(-23,10.7f));
            knight4.addCollisionListener(new KnightCollision(knight4));

            Knight knight5 = new Knight(this);
            knight5.setPosition(new Vec2(-23,18.2f));
            knight5.addCollisionListener(new KnightCollision(knight5));


            // Coins
            // for loop to add coins in intervals
            for(int i = 0; i < 3; ++i){
                Coins coins = new Coins(this);
                coins.setPosition(new Vec2(21+i*2,-4f));}

            for(int i = 0; i < 3; ++i){
                Coins coins2 = new Coins(this);
                coins2.setPosition(new Vec2(21f+i*2,11f));}

            for(int i = 0; i < 3; ++i){
                Coins coins3 = new Coins(this);
                coins3.setPosition(new Vec2(12.5f+i*2,19f));}

            for(int i = 0; i < 3; ++i){
                Coins coins3 = new Coins(this);
                coins3.setPosition(new Vec2(12.5f+i*2,3f));}

            for(int i = 0; i < 3; ++i){
                Coins coins3 = new Coins(this);
                coins3.setPosition(new Vec2(12.5f+i*2,-11f));}


        }



    //if level conditions are met proceed to next level
    @Override
    public boolean isComplete() {
        if (getHero().getScoreCount() >= 10)
            return true;
        else
            return false;
    }

    @Override
    public String getLevelName() {
        return "Level2";
    }
}
