package game.GUI;

import game.Main.Game;
import game.Main.GameLevel;
import game.Main.GameSaveLoad;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

//pause and quit buttons
public class Button extends JPanel {
    private static JButton pauseButton;
    private static int state = 0;
    private static JButton quitButton;
    private static JButton loadButton;
    private static JButton saveButton;
    private static Game game;
    private static JButton instructionButton;

    public static Button createButton(Game game){
        Button but = new Button();

        pauseButton = new JButton("Pause/Play");
        pauseButton.setFont(new Font("Arial", Font.ITALIC, 10));
        pauseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (state == 0){
                    Game.level.stop();
                    state = 1;
                }else{
                    Game.level.start();
                    state = 0;
                }
            }
        });
        pauseButton.setLocation(0, -100);
        but.add(pauseButton);


        quitButton = new JButton("Quit");
        quitButton.setFont(new Font("Italic", Font.BOLD, 10));
        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        but.add(quitButton);

        saveButton = new JButton("Save");
        saveButton.setFont(new Font("Italic", Font.BOLD,10));
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    GameSaveLoad.save(game.getLevel(), "data/save.txt");
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
        });
        but.add(saveButton);


        loadButton = new JButton("Load");
        loadButton.setFont(new Font("Italic", Font.BOLD,10));
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    GameLevel level = GameSaveLoad.load(game,"data/save.txt");
                    game.setLevel(level);
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
        });
        but.add(loadButton);


            // Creates an instruction button that shows how to play the game
            instructionButton = new JButton("Instructions and Controls");
            instructionButton.setFont(new Font("Italic", Font.BOLD, 10));
            instructionButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Controls
                    System.out.println("**********************************************************************************************");
                    System.out.println("* Controls:                                                                                  *");
                    System.out.println("* Left Arrow Key - Walk Left                                                                 *");
                    System.out.println("* Right Arrow Key - Walk Right                                                               *");
                    System.out.println("* Up Arrow Key - Jump                                                                        *");
                    System.out.println("* Num Key 1 - Slash Left                                                                     *");
                    System.out.println("* Num Key 2 - Slash Up                                                                       *");
                    System.out.println("* Num Key 3 - Slash Right                                                                    *");
                    System.out.println("**********************************************************************************************");
                    // Instructions
                    System.out.println("* Collect all the coins, kill all the enemies and report back to Totoro(GREY BEAR) TO WIN!!!!*");
                    System.out.println("**********************************************************************************************");
                }
            });
            but.add(instructionButton);



        return but;
    }
}
