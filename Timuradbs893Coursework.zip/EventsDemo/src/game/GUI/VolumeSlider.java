package game.GUI;

import game.Main.GameLevel;
import city.cs.engine.SoundClip;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;

public class VolumeSlider extends JPanel implements ChangeListener {

    //volume slider
    private static JSlider volumeSlider;
    private static double volume;
    private static int state = 0;
    private static SoundClip gameMusic;


    public static VolumeSlider createSlider() {
        // object created
        VolumeSlider slide = new VolumeSlider();
        // slider created
        volumeSlider = new JSlider(0, 100, 50);
        // paint the ticks and tracks
        volumeSlider.setPaintTrack(true);
        volumeSlider.setPaintTicks(true);
        // set spacing
        volumeSlider.setMajorTickSpacing(50);
        volumeSlider.setMinorTickSpacing(10);
        // setChangeListener
        volumeSlider.addChangeListener(slide);
        // set orientation of slider
        volumeSlider.setOrientation(SwingConstants.VERTICAL);
        // set Font for the slider
        volumeSlider.setFont(new Font("Arial", Font.ITALIC, 10));
        // add slider to panel
        slide.add(volumeSlider);

        // frame size
        slide.setSize(300, 300);
        return slide;
    }

    //change volume if if JSlider value
    public void stateChanged(ChangeEvent e) {
        System.out.println(getVolume());
        GameLevel.gameMusic.setVolume(volume);
    }

    public static Double getVolume() {
        double temp = volumeSlider.getValue();
        if (temp > 0) {
            volume = temp / 1000;
        } else volume = 0.0001;
        return volume;
    }
}