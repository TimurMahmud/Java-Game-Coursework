package game.Controllers;

import game.Bodies.Coins;
import game.Main.GameLevel;
import game.Main.GameView;
import org.jbox2d.common.Vec2;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MouseHandler extends MouseAdapter {

    private GameLevel world;
    private GameView view;

    public MouseHandler(GameLevel w, GameView v){
        world = w;
        view = v;
    }

    @Override
    public void mousePressed(MouseEvent e) {
        //create Coins and add them to world
        Coins coins = new Coins(world);
        //get the mouse coordinates
        Point mousePoint = e.getPoint();
        //transform them to world coordinates
        Vec2 worldPoint = view.viewToWorld(mousePoint);
        //position the books
        coins.setPosition(worldPoint);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }
    @Override
    public void mouseReleased(MouseEvent e) {
    }
    @Override
    public void mouseEntered(MouseEvent e) {
    }
    @Override
    public void mouseExited(MouseEvent e) {
    }
}
