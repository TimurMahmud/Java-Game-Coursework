package game.Controllers;

import city.cs.engine.BodyImage;
import city.cs.engine.SoundClip;
import game.Bodies.Hero;
import game.Bodies.Slash;
import game.Collisions.SlashCollision;
import game.Main.Game;
import game.Main.GameLevel;
import game.Main.GameSaveLoad;
import org.jbox2d.common.Vec2;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.util.logging.Level;

public class HeroController implements KeyListener {

    private static final float WALKING_SPEED = 8;

    private Game game;

    private Hero hero;

    public HeroController(Hero s){
        hero = s;


    }
    //Images and Gifs to be assigned to KeyEvents
    private static final BodyImage heroRight = new BodyImage("data/right.gif",5f);
    private static final BodyImage heroLeft = new BodyImage("data/left.gif",5f);
    private static final BodyImage runRight = new BodyImage("data/walkright.gif",5f);
    private static final BodyImage runLeft = new BodyImage("data/walkleft.gif",5f);
    private static final BodyImage slashRight = new BodyImage("data/swordright.gif",5f);
    private static final BodyImage slashLeft = new BodyImage("data/swordleft.gif",5f);

    //wav files to be assigned to KeyEvents
    private static SoundClip SlashSound;
    static {
        try {
            SlashSound = new SoundClip("data/swordslash.wav");
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
        }
    }

    private static SoundClip JumpSound;
    static {
        try {
            JumpSound = new SoundClip("data/jump.wav");
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
        }
    }


    // In game controls
    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        // other key commands omitted
        if (code == KeyEvent.VK_LEFT) {
            // set walking speed
            hero.startWalking(-WALKING_SPEED);
            // remove previous sprite image
            hero.removeAllImages();
            //add new sprite image
            hero.addImage(runLeft);


        } else if (code == KeyEvent.VK_RIGHT) {
            hero.startWalking(WALKING_SPEED);
            hero.removeAllImages();
            hero.addImage(runRight);


        } else if (code == KeyEvent.VK_UP){
            JumpSound.play();
            // change jump speed
            hero.jump(16);

        } else if(code == KeyEvent.VK_3){
            SlashSound.play();
            // remove current sprite image
            hero.removeAllImages();
            // add new sprite image
            hero.addImage(slashRight);
            // set spawn point (for slash)
            Vec2 selfPoint = hero.getPosition().add(new Vec2(1,1));
            Slash slash = new Slash(hero.getWorld());
            slash.setPosition(selfPoint);
            // set velocity for the slash
            slash.setLinearVelocity(new Vec2(50,0));
            // add collision listener so it gets destroyed on impact
            slash.addCollisionListener(new SlashCollision(slash));

        } else if(code == KeyEvent.VK_1){
            SlashSound.play();
            hero.removeAllImages();
            hero.addImage(slashLeft);
            Vec2 selfPoint = hero.getPosition().add(new Vec2(-1,1));
            Slash slash = new Slash(hero.getWorld());
            slash.setPosition(selfPoint);
            slash.setLinearVelocity(new Vec2(-50,1));
            slash.addCollisionListener(new SlashCollision(slash));
        } else if(code == KeyEvent.VK_2){
            SlashSound.play();
            hero.removeAllImages();
            hero.addImage(slashLeft);
            Vec2 selfPoint = hero.getPosition().add(new Vec2(0,1));
            Slash slash = new Slash(hero.getWorld());
            slash.setPosition(selfPoint);
            slash.setLinearVelocity(new Vec2(0,50));
            slash.addCollisionListener(new SlashCollision(slash));
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_LEFT) {
            // stop walking when key released
            hero.stopWalking();
            // remove current image
            hero.removeAllImages();
            // add default image
            hero.addImage(heroLeft);
        } else if (code == KeyEvent.VK_RIGHT) {
            hero.stopWalking();
            hero.removeAllImages();
            hero.addImage(heroRight);
        }
    }
    public void updateHero(Hero hero){
        this.hero = hero;
    }
}

